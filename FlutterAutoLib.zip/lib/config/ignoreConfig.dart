class NetConfig {
  static const CLIENT_ID = "658d08215f06126a08ef";
  static const CLIENT_SECRET = "a9da8958817c7a834cec0b91235fabce0a8c5744";
}
