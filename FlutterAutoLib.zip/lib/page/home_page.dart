import 'package:flutter/cupertino.dart';

class HomePage extends StatefulWidget {

  static const String sName = "home";

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<_HomePageState> myKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    throw Container();
  }
}