import 'event_bus.dart';

EventBus eventBus = new EventBus();