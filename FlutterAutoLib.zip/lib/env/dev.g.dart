// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dev.dart';

// **************************************************************************
// JsonLiteralGenerator
// **************************************************************************

const _$configJsonLiteral = {'env': 'dev', 'debug': true};
