// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prod.dart';

// **************************************************************************
// JsonLiteralGenerator
// **************************************************************************

const _$configJsonLiteral = {'env': 'prod', 'debug': false};
