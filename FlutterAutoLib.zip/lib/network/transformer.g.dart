// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'transformer.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializers _$serializers =
    (new Serializers().toBuilder()..add(Branch.serializer)).build();

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
